from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password
from django.views import View


class SignUp(View):
    def get(self, request):
         return render(request, 'signup.html')
     
    def validateCustomer(self):
        error_msg = None
        if not self.first_name:
            error_msg = "First name must be provided!!!"
        elif len(self.first_name)<4:
            error_msg = "First name must have at least 4 letters!!!"
        
        if not self.last_name:
            error_msg = "Lastname must be provided!!!"
        elif len(self.last_name)<4:
            error_msg = "Lastname must have at least 4 letters!!!"
            
        if not self.phone:
            error_msg = "Phone number must be provided!!!"
        elif len(self.phone)<10 or len(self.phone)>10:
            error_msg = "Phone number must have at least 10 digits!!!"
            
        if not self.password:
            error_msg = "Password must be provided!!!"
        elif len(self.password)<6:
            error_msg = "Password must have at least 6 characters!!!"
        elif self.email_isExists():
            error_msg = "Email Address already exists!!!"
        return error_msg
    
    def post(self, request):
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('password')
        print(firstname, lastname, phone, email, password)
        # validations
        values = {'firstname': firstname, 'lastname': lastname, 'phone': phone, 'email': email}
        customer_obj = Customer(first_name=firstname, last_name=lastname, phone=phone, email=email, password=password)
        error_msg = SignUp.validateCustomer(customer_obj)
        
        # saving
        if not error_msg: 
            customer_obj.password = make_password(customer_obj.password)           
            customer_obj.register()            
            return redirect('index')
        else:
            return render(request, 'signup.html', {"error_msg": error_msg, 'values': values}) 
        
        
